package com.example.gkeducation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class MediaItem(val name: String, val uri: String, val type: String, val subject: String)
data class ClassItem(val name: String, val description: String, val lessons: List<String>)

private val initialClasses = listOf(
    ClassItem("Class 6", "Foundation GK and Social Studies", listOf("Indian GK Basics", "Geography Basics")),
    ClassItem("Class 7", "Middle-school GK practice", listOf("History Basics", "General Science")),
    ClassItem("Class 8", "Higher-level school preparation", listOf("Constitution Basics", "World GK")),
    ClassItem("Class 9", "School and competitive preparation", listOf("Economics Basics", "Science Practice")),
    ClassItem("Class 10", "Board and competitive exam revision", listOf("Indian Polity", "Current Affairs"))
)

enum class Screen { HOME, SUBJECTS, QUIZ, RESULTS, MEDIA, CLASSES, ADMIN, CLASS_DETAIL }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GKAppV2() }
    }
}

@Composable
fun GKAppV2() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var media by remember { mutableStateOf(emptyList<MediaItem>()) }
    var classes by remember { mutableStateOf(initialClasses) }
    var selectedClass by remember { mutableStateOf<ClassItem?>(null) }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("GK Education", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        if (screen != Screen.HOME) {
                            IconButton({ screen = Screen.HOME }) {
                                Icon(Icons.Default.ArrowBack, "Back")
                            }
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(screen == Screen.HOME, { screen = Screen.HOME },
                        icon = { Icon(Icons.Default.Home, "Home") }, label = { Text("Home") })
                    NavigationBarItem(screen == Screen.SUBJECTS, { screen = Screen.SUBJECTS },
                        icon = { Icon(Icons.Default.MenuBook, "Subjects") }, label = { Text("Quiz") })
                    NavigationBarItem(screen == Screen.MEDIA, { screen = Screen.MEDIA },
                        icon = { Icon(Icons.Default.VideoLibrary, "Media") }, label = { Text("Media") })
                    NavigationBarItem(screen == Screen.CLASSES, { screen = Screen.CLASSES },
                        icon = { Icon(Icons.Default.School, "Classes") }, label = { Text("Classes") })
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (screen) {
                    Screen.HOME -> HomeV2(
                        { screen = Screen.SUBJECTS },
                        { screen = Screen.MEDIA },
                        { screen = Screen.CLASSES },
                        { screen = Screen.ADMIN }
                    )
                    Screen.SUBJECTS -> QuizPlaceholder()
                    Screen.MEDIA -> MediaScreen(media)
                    Screen.CLASSES -> ClassesScreen(classes) {
                        selectedClass = it
                        screen = Screen.CLASS_DETAIL
                    }
                    Screen.CLASS_DETAIL -> selectedClass?.let { ClassDetail(it, media) }
                    Screen.ADMIN -> AdminScreen(
                        media = media,
                        onAddMedia = { item -> media = media + item },
                        onAddClass = { name, desc ->
                            classes = classes + ClassItem(name, desc, emptyList())
                        }
                    )
                    else -> QuizPlaceholder()
                }
            }
        }
    }
}

@Composable
fun HomeV2(onQuiz: () -> Unit, onMedia: () -> Unit, onClasses: () -> Unit, onAdmin: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Learn • Practice • Watch", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("GK Education Version 2")
        }
        item { HomeCard("🧠", "Quizzes", "Practice MCQs and improve your score", onQuiz) }
        item { HomeCard("📸🎬", "Photos & Videos", "Upload and organize educational media", onMedia) }
        item { HomeCard("🎓", "Classes", "Class 6–10 lessons and learning material", onClasses) }
        item { HomeCard("👨‍🏫", "Teacher / Admin", "Add classes, photos and videos", onAdmin) }
    }
}

@Composable
fun HomeCard(icon: String, title: String, desc: String, action: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { action() }, shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 34.sp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(desc)
            }
            Icon(Icons.Default.ChevronRight, "Open")
        }
    }
}

@Composable
fun QuizPlaceholder() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text("Quiz module from Version 1 is ready to be connected here.", fontSize = 18.sp)
    }
}

@Composable
fun MediaScreen(media: List<MediaItem>) {
    if (media.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("📸🎬 No uploaded media yet.
Use Teacher / Admin to add files.", fontSize = 18.sp)
        }
    } else {
        LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
            item { Text("Photos & Videos", fontSize = 28.sp, fontWeight = FontWeight.Bold) }
            items(media) { item ->
                Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(if (item.type == "image") "📸" else "🎬", fontSize = 28.sp)
                        Text(item.name, fontWeight = FontWeight.Bold)
                        Text("Subject: ${item.subject}")
                        Text("Local URI: ${item.uri}", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun ClassesScreen(classes: List<ClassItem>, onSelect: (ClassItem) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("🎓 Classes", fontSize = 28.sp, fontWeight = FontWeight.Bold) }
        items(classes) { c ->
            Card(Modifier.fillMaxWidth().clickable { onSelect(c) }) {
                Column(Modifier.padding(18.dp)) {
                    Text(c.name, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text(c.description)
                    Text("${c.lessons.size} lessons")
                }
            }
        }
    }
}

@Composable
fun ClassDetail(c: ClassItem, media: List<MediaItem>) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp)) {
        item {
            Text("🎓 ${c.name}", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text(c.description)
            Spacer(Modifier.height(18.dp))
            Text("Lessons", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
        if (c.lessons.isEmpty()) {
            item { Text("No lessons added yet.") }
        } else {
            items(c.lessons) { lesson ->
                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    Text("📖 $lesson", Modifier.padding(16.dp))
                }
            }
        }
        item {
            Spacer(Modifier.height(18.dp))
            Text("Available Media", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
        items(media) { item ->
            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                Text("${if (item.type == "image") "📸" else "🎬"} ${item.name}",
                    Modifier.padding(16.dp))
            }
        }
    }
}

@Composable
fun AdminScreen(
    media: List<MediaItem>,
    onAddMedia: (MediaItem) -> Unit,
    onAddClass: (String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("General") }
    var className by remember { mutableStateOf("") }
    var classDesc by remember { mutableStateOf("") }
    var pendingType by remember { mutableStateOf("image") }

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let { onAddMedia(MediaItem(name.ifBlank { "Uploaded photo" }, it.toString(), "image", subject)) }
    }
    val videoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let { onAddMedia(MediaItem(name.ifBlank { "Uploaded video" }, it.toString(), "video", subject)) }
    }

    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("👨‍🏫 Teacher / Admin", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Version 2 local demo: selected files are available during this app session.")
        }
        item { Text("Upload Photo / Video", fontSize = 21.sp, fontWeight = FontWeight.Bold) }
        item {
            OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Title") })
        }
        item {
            OutlinedTextField(subject, { subject = it }, Modifier.fillMaxWidth(), label = { Text("Subject") })
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { pendingType = "image"; imagePicker.launch("image/*") }) {
                    Icon(Icons.Default.Image, "Photo")
                    Spacer(Modifier.width(5.dp))
                    Text("Upload Photo")
                }
                Button(onClick = { pendingType = "video"; videoPicker.launch("video/*") }) {
                    Icon(Icons.Default.VideoLibrary, "Video")
                    Spacer(Modifier.width(5.dp))
                    Text("Upload Video")
                }
            }
        }
        item { Text("Create Class", fontSize = 21.sp, fontWeight = FontWeight.Bold) }
        item {
            OutlinedTextField(className, { className = it }, Modifier.fillMaxWidth(), label = { Text("Class name") })
        }
        item {
            OutlinedTextField(classDesc, { classDesc = it }, Modifier.fillMaxWidth(), label = { Text("Description") })
        }
        item {
            Button(
                onClick = {
                    if (className.isNotBlank()) {
                        onAddClass(className, classDesc)
                        className = ""
                        classDesc = ""
                    }
                },
                enabled = className.isNotBlank(),
                Modifier.fillMaxWidth()
            ) { Text("Create Class") }
        }
        item { Text("Uploaded items: ${media.size}") }
    }
}
