# Slearn Android App — Version 2

Version 2 adds:
- Photos & Videos section
- Android photo picker
- Android video picker
- Teacher/Admin screen
- Create custom classes
- Class 6–10 starter classes
- Class detail/lesson view
- Media listing
- Version 1 project foundation

## Important
This Version 2 is a local prototype. Picked media is represented by Android content URIs and kept in app memory for the current session.

For permanent uploads that students can access from different phones, connect:
- Firebase Authentication
- Firebase Storage
- Cloud Firestore

Those services require a Firebase project and configuration file (`google-services.json`). This ZIP intentionally does not contain private cloud credentials.

## Run
Open the folder in Android Studio, sync Gradle, connect an Android device/emulator, and press Run.
